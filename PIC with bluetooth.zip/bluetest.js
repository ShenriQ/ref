var SerialPort = require('serialport');// include the library
var myPort = new SerialPort('/dev/rfcomm0', { autoOpen: false });
var fs = require('fs');
fs.open('dataout.txt', 'w', function (err, file) {
  if (err) throw err;});
var readline = require('readline-sync');

var i=0;
var j=0;
var k=0;
var sum=0;
var kk=0;
var a = new Array();
var lth = new Array();
var nval = new Array();
var xx,yy,xxn,yyn;
var ntot = readline.question("input ntot:  ");  //Input the number of bytes to be read

myPort.on('open', showPortOpen);
myPort.on('close', showPortClose);
myPort.on('error', showError);
myPort.on('data', readdata);


function readdata(data)
{
  i=i+1;                                     //Counts the number of times data is read
  a[i]= data.toString('hex');                //save data in hex format
  lth[i]= Buffer.byteLength(a[i],'utf8');    //save the length of the hex data
  sum=sum+lth[i];
  if (sum>=2*ntot)                          //Once ntot bytes have been read do
   {
    k=0;
    for(j=1;j<(i+1);j++)
     {
      for(kk=0;kk<lth[j];kk=kk+2)
      {
       xx=a[j].charCodeAt(kk);              //xx is the kk'th nibble
       yy=a[j].charCodeAt(kk+1);            //yy is the (kk+1)th nibble
       if (xx < 90) {xxn= xx-48}            //for nibble's that are 0-9
        else {xxn=xx-87};                   //for nibble's that are 10-15
       if (yy < 90) {yyn= yy-48} 
        else {yyn=yy-87};
       nval[k]=parseFloat(16*xxn+yyn);     //combine the two nibbles to make a byte (0-255)
       k=k+1;
      }
     }

     for (k=0;k<ntot;k++)
      {
       console.log(k, nval[k]);             //print out the k'th byte
       fs.appendFileSync('dataout.txt', nval[k].toFixed(2)+'\n');
      }
//     for (k=1;k<=i;k++)
//      {
//       console.log(k, lth[k]);   //print out the length of the k'th data read
//      }
     fs.close('dataout.txt');
     myPort.close(showPortClose());
   }
}
function showPortOpen() {
   myPort.flush();
}


 function showPortClose() {
   console.log('port closed.');
}

function showError(error) {
   console.log('Serial port error: ' + error);
}

myPort.open(function (err) {
  if (err) {
    return console.log('Error opening port: ', err.message);
  }});


