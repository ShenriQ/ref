#include <stdio.h>
#include <fcntl.h> 
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <termios.h>
#include <string.h>

int main(int argc, char **argv)
{
  FILE *outf, *inf;  
  unsigned char data[20];
  inf = fopen("/dev/rfcomm0","r");
  int nbytes = 20;
  int i,j;
  float time;

  outf=fopen("data.txt","w");
  for (i=0;i<nbytes;i++)
   {
    data[i]=fgetc(inf);
    printf("%u \n", data[i]);
    fprintf(outf,"%d \n", data[i]);
   }

}

